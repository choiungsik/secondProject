package com.model;

public class CompaniesDTO {
	
	private int compnum;
	private String compname;
	private String comptal1;
	private String comptal2;
	private String comptal3;
	
	private String comp1;
	private String comp2;
	private String comp3;

	public int getCompnum() {
		return compnum;
	}

	public void setCompnum(int compnum) {
		this.compnum = compnum;
	}

	public String getCompname() {
		return compname;
	}

	public void setCompname(String compname) {
		this.compname = compname;
	}

	public String getComptal1() {
		return comptal1;
	}

	public void setComptal1(String comptal1) {
		this.comptal1 = comptal1;
	}

	public String getComptal2() {
		return comptal2;
	}

	public void setComptal2(String comptal2) {
		this.comptal2 = comptal2;
	}

	public String getComptal3() {
		return comptal3;
	}

	public void setComptal3(String comptal3) {
		this.comptal3 = comptal3;
	}
	
	public String getComp1() {
		return comp1;
	}

	public void setComp1(String Comp1) {
		this.comp1 = Comp1;
	}

	public String getComp2() {
		return comp2;
	}

	public void setComp2(String Comp2) {
		this.comp2 = Comp2;
	}
	
	public String getComp3() {
		return comp3;
	}

	public void setComp3(String comp3) {
		this.comp3 = comp3;
	}

	public CompaniesDTO(int compnum, String compname) {
		this.compnum = compnum;
		this.compname = compname;
	}
	
	public CompaniesDTO(String compname, String comptal1, String comptal2) {
		this.compname = compname;
		this.comptal1 = comptal1;
		this.comptal2 = comptal2;
	}

	public CompaniesDTO(String compname, String comptal1, String comptal2, String comptal3, String comp1,
			String comp2) {
		this.compname = compname;
		this.comptal1 = comptal1;
		this.comptal2 = comptal2;
		this.comptal3 = comptal3;
		this.comp1 = comp1;
		this.comp2 = comp2;
	}

	public CompaniesDTO(String compname) {
		this.compname = compname;
	}

	public CompaniesDTO(int compnum, String comp1, String comp2, String comp3) {
		this.compnum = compnum;
		this.comp1 = comp1;
		this.comp2 = comp2;
		this.comp3 = comp3;
	}
	
}
