package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MemberDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	MemberDTO info = null;
	ResultSet rs = null;
	ArrayList<MemberDTO> list = null;
	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String db_url = "jdbc:oracle:thin:@localhost:1521:xe";
			String db_id = "hr";
			String db_pw = "hr";

			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int join(MemberDTO dto) {
		conn();
		try {
			String sql = "insert into members values(?,?,?,?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getName());
			psmt.setInt(2, dto.getAge());
			psmt.setString(3, dto.getId());
			psmt.setString(4, dto.getPw());
			cnt = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return cnt;
	}
	
	public MemberDTO login(MemberDTO dto) {
		
		conn();
		try {
			String sql = "select * from members where id = ? and pw = ?";
			psmt = conn.prepareStatement(sql);
			System.out.println(dto.getId());
			System.out.println(dto.getPw());
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getPw());

			rs = psmt.executeQuery();
			// update�� intŸ��
			// ������ �ٲ����� �����Ƿ� executeQuery���
			
			if(rs.next()) {
				String name = rs.getString(1);
				// rs.next()�� true�� if���� ����Ǵϱ� getString�� ����� �� �ִ�.
				int age = rs.getInt(2);
				String id= rs.getString(3);
				String pw = rs.getString(4);
				
				info = new MemberDTO(name, age, id, pw);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		return info;
	}
	
public MemberDTO logon(MemberDTO dto) {
		
		conn();
		try {
			String sql = "select * from members where id = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getId());

			rs = psmt.executeQuery();
			// update�� intŸ��
			// ������ �ٲ����� �����Ƿ� executeQuery���
			
			if(rs.next()) {
				String name = rs.getString(1);
				// rs.next()�� true�� if���� ����Ǵϱ� getString�� ����� �� �ִ�.
				int age = rs.getInt(2);
				String id= rs.getString(3);
				String pw = rs.getString(4);
				
				info = new MemberDTO(name, age, id, pw);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		return info;
	}
	
	/*
	 * public int update(MemberDTO info) { conn(); try { String sql =
	 * "update members set pw = ?, tel = ?, address = ? where email =?"; psmt =
	 * conn.prepareStatement(sql);
	 * 
	 * psmt.setString(1, info.getPw()); psmt.setString(2, info.getTel());
	 * psmt.setString(3, info.getAddr()); psmt.setString(4, info.getEmail());
	 * 
	 * cnt = psmt.executeUpdate();
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); }finally { close(); } return
	 * cnt; }
	 */
	
	
	
	/*
	 * public ArrayList<MemberDTO> select() { list = new ArrayList<MemberDTO>();
	 * 
	 * try { conn(); String sql = "select * from web_member"; psmt =
	 * conn.prepareStatement(sql);
	 * 
	 * psmt.executeQuery(); // ResultSet ���·� ��ȯ
	 * 
	 * while(rs.next()) { String email = rs.getString(1); String pw =
	 * rs.getString(2); String tel = rs.getString(3); String addr = rs.getString(4);
	 * 
	 * info = new MemberDTO(email, pw, tel, addr); list.add(info); } } catch
	 * (SQLException e) { e.printStackTrace(); } finally { close(); } return list; }
	 */
}