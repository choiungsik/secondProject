package com.model;

public class TalentDTO {

	private int talnum;
	private String id;
	private String title;
	private String content;
	private String talent1;
	private float talentper1;
	private String talent2;
	private float talentper2;
	
	public TalentDTO(String title, String content) {
		this.title = title;
		this.content = content;
	}
	
	public TalentDTO(String id, String title, String content, String talent) {
		this.id = id;
		this.title = title;
		this.content = content;
		this.talent1 = talent;
	}

	public TalentDTO(int talnum, String id, String title, String content, String talent) {
		this.talnum = talnum;
		this.id = id;
		this.title = title;
		this.content = content;
		this.talent1 = talent;
	}
	
	public TalentDTO(int talnum, String id, String title, String content, String talent1,  float talentper1, String talent2, float talentper2) {
		this.talnum = talnum;
		this.id = id;
		this.title = title;
		this.content = content;
		this.talent1 = talent1;
		this.talentper1 = talentper1;
		this.talent2 = talent2;
		this.talentper2 = talentper2;
	}
	
	public TalentDTO(String id, String title, String content, String talent1,  float talentper1, String talent2, float talentper2) {
		this.id = id;
		this.title = title;
		this.content = content;
		this.talent1 = talent1;
		this.talentper1 = talentper1;
		this.talent2 = talent2;
		this.talentper2 = talentper2;
	}

	public int getTalnum() {
		return talnum;
	}

	public void setTalnum(int talnum) {
		this.talnum = talnum;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getTalent1() {
		return talent1;
	}

	public void setTalent1(String talent1) {
		this.talent1 = talent1;
	}
	
	public float getTalentper1() {
		return talentper1;
	}

	public void setTalentper1(float talentper1) {
		this.talentper1 = talentper1;
	}
	public String getTalent2() {
		return talent2;
	}

	public void setTalent2(String talent2) {
		this.talent1 = talent2;
	}
	
	public float getTalentper2() {
		return talentper2;
	}

	public void setTalentper2(float talentper2) {
		this.talentper2 = talentper2;
	}
	
	
	
}
