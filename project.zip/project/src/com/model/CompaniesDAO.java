package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CompaniesDAO {


	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	CompaniesDTO info = null;
	ResultSet rs = null;
	ArrayList<CompaniesDTO> list = null;
	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String db_url = "jdbc:oracle:thin:@localhost:1521:xe";
			String db_id = "hr";
			String db_pw = "hr";

			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public int insert(CompaniesDTO dto) {

		try {
			conn();
			String sql = "insert into companies values(compnum_sequence.nextval, ?, ?, ?, ?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getCompname());
			psmt.setString(2, dto.getComptal1());
			psmt.setString(3, dto.getComptal2());
			psmt.setString(4, dto.getComptal3());

			cnt = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}
	
	public int insertcomp(CompaniesDTO dto) {

		try {
			conn();
			String sql = "insert into tal_comp values(?, ?, ?, ?)";
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, dto.getCompnum());
			psmt.setString(2, dto.getComp1());
			psmt.setString(3, dto.getComp2());
			psmt.setString(4, dto.getComp3());

			cnt = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}

	public ArrayList<CompaniesDTO> select(int tal_num) {

		list = new ArrayList<CompaniesDTO>();
		
		try {
			conn();
			System.out.println("db����");
			String sql = "select * from tal_comp where talnum = ? order by talnum";
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, tal_num);
			System.out.println(tal_num);
			
			rs = psmt.executeQuery();
			System.out.println("����Ʈ�� ����");
			
			while(rs.next()) { 
				int compnum = rs.getInt(1);
				String comp1 = rs.getString(2);
				String comp2 = rs.getString(3);
				String comp3 = rs.getString(4);
				
				info = new CompaniesDTO(compnum, comp1, comp2, comp3); 
				list.add(info);
				System.out.println("�� ����Ʈ ����");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
	
	
}
