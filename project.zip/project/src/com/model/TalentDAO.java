package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TalentDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	ResultSet rs = null;
	TalentDTO dto = null;
	ArrayList<TalentDTO> list = null;

	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String db_url = "jdbc:oracle:thin:@localhost:1521:xe";
			String db_id = "hr";
			String db_pw = "hr";

			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int insert(TalentDTO dto) {

		try {
			conn();
			String sql = "insert into talents values(talnum_sequence.nextval, ?, ?, ?, ?, ?, ?, ?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getTitle());
			psmt.setString(3, dto.getContent());
			psmt.setString(4, dto.getTalent1());
			psmt.setFloat(5, dto.getTalentper1()*100);
			psmt.setString(6, dto.getTalent2());
			psmt.setFloat(7, dto.getTalentper2()*100);

			cnt = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}

	public ArrayList<TalentDTO> select(String id) {
		list = new ArrayList<TalentDTO>();

		try {
			conn();

			String sql = "select * from talents where id = ? order by talnum";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);
			rs = psmt.executeQuery();

			while (rs.next()) {

				int num = rs.getInt(1);
				String title = rs.getString(3);
				String content = rs.getString(4);
				String talent1 = rs.getString(5);
				float talentper1 = rs.getFloat(6);
				String talent2 = rs.getString(7);
				float talentper2 = rs.getFloat(8);

				dto = new TalentDTO(num, id, title, content, talent1, talentper1, talent2, talentper2);
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return list;

	}

	public int delete(String id) {
		try {
			conn();

			String sql = "delete from talents where id = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);

			cnt = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return cnt;
	}

	public int deleteOne(String num) {
		try {
			conn();

			String sql = "delete from talents where talnum = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, num);

			cnt = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return cnt;
	}
}
