package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Front.Command;
import com.model.MemberDTO;
import com.model.MessageDAO;

public class DeleteServiceCon implements Command {

	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String moveURL = null;

		HttpSession session = request.getSession();
		MemberDTO info = (MemberDTO) session.getAttribute("info");

		MessageDAO dao = new MessageDAO();
		int cnt = dao.delete(info.getId());

		if (cnt > 0) {
			System.out.println("���� ���� !");
		} else {
			System.out.println("���� ���� !");
		}

		moveURL = "main.jsp";
		return moveURL;
	}

}
