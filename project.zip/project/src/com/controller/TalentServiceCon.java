package com.controller;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Front.Command;
import com.model.MemberDTO;
import com.model.TalentDAO;
import com.model.TalentDTO;

public class TalentServiceCon implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String moveURL = null;
		
		try {
			request.setCharacterEncoding("EUC-KR");
			response.setCharacterEncoding("EUC-KR");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		HttpSession session = request.getSession();
		MemberDTO info = (MemberDTO)session.getAttribute("info");
		String id = info.getId();
		String title = request.getParameter("title");
		String content = request.getParameter("contents");
		String talent1 = "passion";
		int talentper1 = 30;
		String talent2 = "passion";
		int talentper2 = 30;
	
		TalentDAO dao = new TalentDAO();
		TalentDTO dto = new TalentDTO(id, title, content, talent1, talentper1, talent2, talentper2);
		System.out.println(id);
		System.out.println(title);
		System.out.println(content);
		System.out.println(talent1);
		System.out.println(talentper1);
		System.out.println(talent2);
		System.out.println(talentper2);
		int cnt = dao.insert(dto);
		
		if(cnt > 0) {
			System.out.println("�ڼҼ� ��� ����!");
		} else {
			System.out.println("�ڼҼ� ��� ����!");
		}
		
		moveURL = "index.jsp";
		return moveURL;
	}

}
