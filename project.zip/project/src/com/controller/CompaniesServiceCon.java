package com.controller;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Front.Command;
import com.model.CompaniesDAO;
import com.model.CompaniesDTO;
import com.model.MemberDTO;
import com.model.TalentDAO;
import com.model.TalentDTO;

public class CompaniesServiceCon implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String moveURL = null;

		try {
			request.setCharacterEncoding("EUC-KR");
			response.setCharacterEncoding("EUC-KR");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		HttpSession session = request.getSession();
		MemberDTO info = (MemberDTO) session.getAttribute("info");
		int num = Integer.parseInt(request.getParameter("compnum"));
		String name = request.getParameter("compname");
		/* String talent = "passion"; */

		CompaniesDAO dao = new CompaniesDAO();
		CompaniesDTO dto = new CompaniesDTO(num, name);
		System.out.println(num);
		System.out.println(name);

		int cnt = dao.insert(dto);

		if (cnt > 0) {
			
		} else {
			
		}

		moveURL = "index.jsp";
		return moveURL;
	}

}
