package com.controller;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.Front.Command;
import com.model.MemberDAO;
import com.model.MemberDTO;

public class LoginServiceCon implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		String moveURL = null;
		
		String id = request.getParameter("fname");
		String pw = request.getParameter("subject");

		MemberDAO dao = new MemberDAO();
		MemberDTO dto = new MemberDTO(id, pw);

		MemberDTO info = dao.login(dto);

		if (info != null) {
			System.out.println("�α��� ����!");

			HttpSession session = request.getSession();
			session.setAttribute("info", info);
			System.out.println(session.getAttribute("info"));
		} else {
			System.out.println("�α��� ����!");
		}
		moveURL = "index.jsp";

		return moveURL;
	}

}
