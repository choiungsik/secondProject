package com.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Front.Command;
import com.model.MemberDAO;
import com.model.MemberDTO;

public class JoinServiceCon implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String moveURL = null;
				
		String name = request.getParameter("name");
		int age = Integer.parseInt(request.getParameter("age"));
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		MemberDAO dao = new MemberDAO();
		MemberDTO dto = new MemberDTO(name, age, id, pw);
		int cnt = dao.join(dto);
		
		if(cnt > 0) {
			System.out.println("ȸ������ ����!");
			moveURL = "index.jsp";
			
		} else {
			System.out.println("ȸ������ ����!");
			moveURL = "index.jsp";
		}
		
		return moveURL;
	}

}
