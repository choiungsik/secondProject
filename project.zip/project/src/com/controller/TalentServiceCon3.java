package com.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.CompaniesDAO;
import com.model.CompaniesDTO;
import com.model.MemberDAO;
import com.model.MemberDTO;
import com.model.TalentDAO;
import com.model.TalentDTO;

/**
 * Servlet implementation class TalentServiceCon3
 */
@WebServlet("/TalentServiceCon3")
public class TalentServiceCon3 extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		String id = request.getParameter("id");
		System.out.println(id);
		String title = request.getParameter("title");
		String content = request.getParameter("contents");
		String talent1 = request.getParameter("talented1");
		String talent2 = request.getParameter("talented2");
		System.out.println(request.getParameter("prob1"));
		float prob1 = Float.parseFloat(request.getParameter("prob1"));
		float prob2 = Float.parseFloat(request.getParameter("prob2"));
		String com1 = request.getParameter("com1");
		String com2 = request.getParameter("com2");
		String com3 = request.getParameter("com3");

		TalentDAO dao = new TalentDAO();
		TalentDTO dto = new TalentDTO(id, title, content, talent1, prob1, talent2, prob2);
		System.out.println(id);
		System.out.println(title);
		System.out.println(content);
		System.out.println(talent1);
		System.out.println(prob1);
		System.out.println(talent2);
		System.out.println(prob2);
		System.out.println(com1);
		System.out.println(com2);
		System.out.println(com3);
		System.out.println("talent �μ�Ʈ");
		int cnt = dao.insert(dto);
		
		if(cnt > 0) {
			System.out.println("�ڼҼ� ��� ����!");
		} else {
			System.out.println("�ڼҼ� ��� ����!");
		}
		
		ArrayList<TalentDTO> tal_list = dao.select(id);
		int num = tal_list.get(tal_list.size()-1).getTalnum();
		
		CompaniesDAO ao = new CompaniesDAO();
		CompaniesDTO to = new CompaniesDTO(num, com1, com2, com3);
		System.out.println(num);
		System.out.println("tal_com �μ�Ʈ");
		cnt = ao.insertcomp(to);
		
		if(cnt > 0) {
			System.out.println("ȸ�翬�� ����!");
		} else {
			System.out.println("ȸ�翬�� ����!");
		}
		
		MemberDAO co = new MemberDAO();
		MemberDTO xo = new MemberDTO(id);

		MemberDTO info = co.logon(xo);
		
		HttpSession session = request.getSession();
		session.setAttribute("info", info);
		System.out.println(session.getAttribute("info"));
		
		response.sendRedirect("index.jsp");
	}

}
