package com.controller;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.MemberDTO;
import com.model.TalentDAO;
import com.model.TalentDTO;

public class TalentServiceCon2 {

	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
	try {
		request.setCharacterEncoding("EUC-KR");
		response.setCharacterEncoding("EUC-KR");
	} catch (UnsupportedEncodingException e) {
		e.printStackTrace();
	}
	
	HttpSession session = request.getSession();
	MemberDTO info = (MemberDTO)session.getAttribute("info");
	String id = info.getId();
	String title = request.getParameter("title");
	String content = request.getParameter("contents");
	String talent = "fession";

	TalentDAO dao = new TalentDAO();
	TalentDTO dto = new TalentDTO(id, title, content, talent);
	System.out.println(id);
	System.out.println(title);
	System.out.println(content);
	System.out.println(talent);
	int cnt = dao.insert(dto);
	
	if(cnt > 0) {
		System.out.println("�ڼҼ� ��� ����!");
	} else {
		System.out.println("�ڼҼ� ��� ����!");
	}
	
	}
	
}
