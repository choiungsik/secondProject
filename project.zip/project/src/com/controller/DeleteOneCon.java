package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Front.Command;
import com.model.MessageDAO;
import com.model.TalentDAO;

public class DeleteOneCon implements Command{

	public String execute(HttpServletRequest request, HttpServletResponse response) {

		String moveURL = null;
		String num = request.getParameter("num");
		System.out.println(num);

		TalentDAO dao = new TalentDAO();
		int cnt = dao.deleteOne(num);

		if (cnt > 0) {
			System.out.println("���� ���� !");
		} else {
			System.out.println("���� ���� !");
		}
		
		moveURL = "index.jsp";
		return moveURL;
	}
}