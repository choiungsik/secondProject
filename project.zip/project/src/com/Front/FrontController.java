package com.Front;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.CompaniesServiceCon;
import com.controller.DeleteOneCon;
import com.controller.DeleteServiceCon;
import com.controller.JoinServiceCon;
import com.controller.LoginServiceCon;
import com.controller.Logout;
import com.controller.TalentServiceCon;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		// ������ �޾ƿ� ��
		response.setCharacterEncoding("utf-8");
		// ���ڵ��� �׻� ���� ���� !
		// ������ ���� ��
		PrintWriter out = response.getWriter();
		/* out.print("����Ʈ�Դϴ�."); */
		
		String reqURI = request.getRequestURI();
		// ��� ���������� �˷���
		System.out.println(reqURI);
		
		String path = request.getContextPath();
		System.out.println(path);
		
		String resultURI = reqURI.substring(path.length()+1);
		System.out.println(resultURI);
		
		Command command = null;
		String moveURL = null;
		
		if(resultURI.equals("DeleteOneCon.do")) {	
			command = new DeleteOneCon();
			
		} else if(resultURI.equals("DeleteServiceCon.do")) {
			command = new DeleteServiceCon();
			
		} else if(resultURI.equals("JoinServiceCon.do")) {
			command = new JoinServiceCon();
			
		} else if(resultURI.equals("LoginServiceCon.do")) {
			command = new LoginServiceCon();
			
		} else if(resultURI.equals("Logout.do")) {
			command = new Logout();
			
		} else if(resultURI.equals("TalentServiceCon.do")) {
			command = new TalentServiceCon();
		
		}else if(resultURI.equals("CompaniesServiceCon.do")) {
			command = new CompaniesServiceCon();		
		}
		
		moveURL = command.execute(request, response);
		response.sendRedirect(moveURL);
		
	
	}
}
