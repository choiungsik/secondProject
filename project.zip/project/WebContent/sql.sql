drop table members cascade constraint;
drop table talents cascade constraint;
drop table companies cascade constraint;
drop table tal_comp cascade constraint;
drop sequence talnum_sequence;
drop sequence compnum_sequence;

create sequence talnum_sequence
increment by 1
start with 1
maxvalue 9999;

create sequence compnum_sequence
increment by 1
start with 1
maxvalue 9999;

create table members(
name varchar(20) constraint members_name_nn not null,
age number(10),
id varchar(20),
pw varchar(20) constraint members_pw_nn not null,
constraint members_id_pk primary key(id));

create table talents(
talnum number(20),
id varchar(20) constraint talents_id_nn not null,
title varchar(100) constraint talents_title_nn not null,
content varchar(4000) constraint talents_content_nn not null,
talent1 varchar(20),
talentper1 number(5),
talent2 varchar(20),
talentper2 number(5),
constraint talents_talnum_pk primary key(talnum),
constraint talents_id_fk foreign key(id)
references members(id));

create table companies(
compnum number(20),
compname varchar(100) constraint companies_compname_nn not null,
comptal1 varchar(20) constraint companies_comptal1_nn not null,
comptal2 varchar(20),
comptal3 varchar(20),
constraint companies_compnum_pk primary key(compnum));

create table tal_comp(
talnum number(20),
compname1 varchar(100) constraint tal_comp_compname_nn not null,
compname2 varchar(100),
compname3 varchar(100),
constraint tal_comp_talnum_pk primary key(talnum),
constraint tal_comp_talnum_fk foreign key(talnum)
references talents(talnum)
on delete cascade);

--,constraint companies_compname_uk unique(compname)
--,
--constraint companies_compname1_fk foreign key(compname1)
--references companies(compname)

insert into members(name, age, id, pw)
values ('111', '111', 'wow', 12);

insert into talents(talnum, id, title, content, talent1, talentper1, talent2, talentper2)
values (talnum_sequence.nextval, 'wow', 'gogo', 'wow', 'passion', 30, 'positive', 25);

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '���̹�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'Ű������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ���������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����ι���', 'inno', 'inno', 'leadership');

insert into tal_comp(talnum, compname1)
values (1, '��������');

insert into tal_comp(talnum, compname1, compname2, compname3)
values (2, '���̹�', '����', '����');

select*from members;

select*from talents;

select*from tal_comp;

select*from companies;

select * from members where id = '111' and pw = '111'

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'SK����ȭ��', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'SK��Ʈ����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'SK�Ǽ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'SK����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'SK', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'S-oil', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'LGȭ��', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'LG�̳���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'LG���÷���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'LG��Ȱ�ǰ�', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'LG���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'LG', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'KT', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'KB���غ���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'kb����ī��', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'KB ����', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'īī��', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'IBK', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'gsĮ�ؽ�', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'GS������', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'gs�Ǽ�', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'DB���غ���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'CJ��������', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'AXA ���غ���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ﱹ��������', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'Ȩ�÷���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ե�ȣ��', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�����ػ�', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�����߰���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '������ö', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�����ڵ���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '������Ϲ�ũ', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '���뿣���Ͼ', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '����۷κ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '����Ǽ�', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��ȭ��Ż', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��ȭ�ɹ�Į', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��ȭ���غ���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��ȭ�׷�', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '����KDN', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '���� kps', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '����', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѻ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ���������', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ��������ð���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ�Ÿ�̾�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ�ö������', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ�����', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����ι���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����±��', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ������������', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����������', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����ڿ����� ', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����¿��ڷ�', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����ι���', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ�����ȸ', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ���������', 'inno', 'inno', 'leadership');
insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����ΰ���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '11����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ǰ�����ɻ��򰡿�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�����ƿ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '����ڵ���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '���̽�������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ؽ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '������������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�븲���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '���Ǽ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������ؾ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�����װ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�����׷�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�λ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�λ��������ھ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ե�����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ե��ɹ�Į', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ް��ڽ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�޸�����������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�޸���ȭ��', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '���׷�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ｚ', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ｚ���÷���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ｚ�޵�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ｚ����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ｚ����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ｚ�����𿡽�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ｚ����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ｚ���ڼ���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ｚȭ��', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ＺSDI', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '����ǰ', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ż���(������)', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '��������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�Ƹ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ƽþƳ��װ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ְ���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�����ؾ������۷��̼�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�������ϲ�������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '���ѱ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�츮����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�̷������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�̸�Ʈ24', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�α���', 'inno', 'inno', 'leadership');


insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ڸ��ȸ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'ũ���� ��Ʈ�ʽ�', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, 'Ű������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�佺', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ϳ�����', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ� ����ȸ', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ���������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����װ��� ', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ���������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ���������', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ����ι���', 'inno', 'inno', 'leadership');

insert into companies(compnum, compname, comptal1, comptal2, comptal3)
values (compnum_sequence.nextval, '�ѱ�����̰���', 'inno', 'inno', 'leadership');

